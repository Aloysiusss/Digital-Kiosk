===============================================================
             AFTER INSERTING BILL LOADING SCREEN
===============================================================

1. PURPOSE
---------------------------------------------------------------
LoadingForm is a borderless, full-screen modal form displayed 
while a long-running process is ongoing (e.g., printing receipt).
It prevents user interaction and shows a loading spinner with a 
message and a live clock timestamp in the footer. 15 seconds set 
before going to Form6 (final form)


